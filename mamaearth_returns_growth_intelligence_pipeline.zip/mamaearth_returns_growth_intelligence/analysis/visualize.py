"""
Mamaearth Returns & Growth Intelligence — Part 2 visualizations.
Run after:
    python analysis/clean_and_eda.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

orders = pd.read_csv(DATA / "orders.csv")
customers = pd.read_csv(DATA / "customers.csv")
products = pd.read_csv(DATA / "products.csv")

orders["payment_method"] = orders["payment_method"].str.strip().str.upper()

natural_key = [
    "customer_id", "product_id", "order_date", "quantity",
    "discount_pct", "payment_method", "rating", "returned"
]
orders = orders.loc[~orders.duplicated(subset=natural_key, keep="first")].copy()
orders["discount_pct"] = orders["discount_pct"].fillna(0)
orders["rating"] = orders["rating"].fillna(orders["rating"].median())

merged = (
    orders
    .merge(products, on="product_id", how="left", validate="many_to_one")
    .merge(customers, on="customer_id", how="left", validate="many_to_one")
)
merged["order_value"] = (
    merged["quantity"] * merged["price"] *
    (1 - merged["discount_pct"] / 100.0)
)
merged["is_outlier"] = ~merged["quantity"].between(
    merged["quantity"].quantile(0.25) -
    1.5 * (merged["quantity"].quantile(0.75) - merged["quantity"].quantile(0.25)),
    merged["quantity"].quantile(0.75) +
    1.5 * (merged["quantity"].quantile(0.75) - merged["quantity"].quantile(0.25))
)

# Visualization 1: payment return rate
rates = (
    orders.groupby("payment_method")["returned"]
    .mean().mul(100).sort_values(ascending=False)
)
fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(rates.index, rates.values)
ax.set_title("COD Returns at 44.4% — 3x Card")
ax.set_xlabel("Payment Method")
ax.set_ylabel("Return Rate (%)")
ax.set_ylim(0, max(rates.values) * 1.25)
for bar, value in zip(bars, rates.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
            f"{value:.1f}%", ha="center", va="bottom")
fig.tight_layout()
fig.savefig(OUT / "return_rate_by_payment.png", dpi=160)
plt.close(fig)

# Visualization 2: corrected monthly revenue
merged["order_date"] = pd.to_datetime(merged["order_date"])
merged["year_month"] = merged["order_date"].dt.to_period("M").astype(str)
monthly = (
    merged.loc[~merged["is_outlier"]]
    .groupby("year_month")["order_value"].sum()
)
peak_month = monthly.idxmax()

fig, ax = plt.subplots(figsize=(9, 5))
ax.plot(monthly.index, monthly.values, marker="o")
ax.set_title(f"Outlier-Corrected Monthly Revenue — Peak: {peak_month}")
ax.set_xlabel("Month")
ax.set_ylabel("Revenue (INR)")
ax.tick_params(axis="x", rotation=30)
fig.tight_layout()
fig.savefig(OUT / "monthly_revenue_trend.png", dpi=160)
plt.close(fig)

print("Generated:")
print(OUT / "return_rate_by_payment.png")
print(OUT / "monthly_revenue_trend.png")
