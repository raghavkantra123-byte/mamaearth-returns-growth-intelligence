"""
Mamaearth Returns & Growth Intelligence — Part 2
Run from repository root:
    python analysis/clean_and_eda.py

The pipeline intentionally reads the raw CSV files directly and never modifies them.
At the end, it writes narrator/findings.json from the values computed in this run.
"""
from pathlib import Path
import json
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
NARRATOR = ROOT / "narrator"
NARRATOR.mkdir(exist_ok=True)

print("=" * 80)
print("TASK 1 — LOAD AND INSPECT")
print("=" * 80)
orders = pd.read_csv(DATA / "orders.csv")
customers = pd.read_csv(DATA / "customers.csv")
products = pd.read_csv(DATA / "products.csv")

print("orders.shape before cleaning:", orders.shape)
print("customers.shape:", customers.shape)
print("products.shape:", products.shape)
assert orders.shape == (180, 9)

print("\n" + "=" * 80)
print("TASK 2 — STANDARDIZE PAYMENT METHOD")
print("=" * 80)
print("Raw payment_method unique values:", sorted(orders["payment_method"].unique().tolist()))
assert orders["payment_method"].nunique() == 7

orders["payment_method"] = orders["payment_method"].str.strip().str.upper()
print("Cleaned payment_method counts:")
print(orders["payment_method"].value_counts().sort_index())
expected_payment_counts = {"CARD": 70, "COD": 55, "UPI": 55}
assert orders["payment_method"].nunique() == 3
assert orders["payment_method"].value_counts().to_dict() == expected_payment_counts

print("\n" + "=" * 80)
print("TASK 3 — REMOVE DUPLICATE ORDERS")
print("=" * 80)
natural_key = [
    "customer_id", "product_id", "order_date", "quantity",
    "discount_pct", "payment_method", "rating", "returned"
]
duplicate_mask = orders.duplicated(subset=natural_key, keep="first")
dropped = orders.loc[duplicate_mask].copy()
print("Duplicate rows flagged:", len(dropped))
print("Dropped order_id values:", dropped["order_id"].tolist())
assert len(dropped) == 5
assert dropped["order_id"].tolist() == ["O0176", "O0177", "O0178", "O0179", "O0180"]

orders_clean = orders.loc[~duplicate_mask].copy()
print("orders_clean.shape:", orders_clean.shape)
assert orders_clean.shape == (175, 9)

print("\n" + "=" * 80)
print("TASK 4 — IMPUTE MISSING VALUES")
print("=" * 80)
discount_missing = int(orders_clean["discount_pct"].isna().sum())
rating_missing = int(orders_clean["rating"].isna().sum())
print("Missing discount_pct before imputation:", discount_missing)
print("Missing rating before imputation:", rating_missing)
assert discount_missing == 12
assert rating_missing == 15

rating_median = float(orders_clean["rating"].median())
print("Median rating before imputation:", rating_median)
assert rating_median == 3.0

orders_clean["discount_pct"] = orders_clean["discount_pct"].fillna(0)
orders_clean["rating"] = orders_clean["rating"].fillna(rating_median)
print("Missing values after imputation:")
print(orders_clean[["discount_pct", "rating"]].isnull().sum().to_dict())
assert orders_clean[["discount_pct", "rating"]].isnull().sum().to_dict() == {
    "discount_pct": 0, "rating": 0
}

print("\n" + "=" * 80)
print("TASK 5 — MERGE AND RECONCILE AGAINST PART 1")
print("=" * 80)
merged = (
    orders_clean
    .merge(products, on="product_id", how="left", validate="many_to_one")
    .merge(customers, on="customer_id", how="left", validate="many_to_one")
)
merged["order_value"] = (
    merged["quantity"] * merged["price"] *
    (1 - merged["discount_pct"] / 100.0)
)
clean_total = float(merged["order_value"].sum())
print(f"Cleaned total revenue: {clean_total:,.2f}")
assert round(clean_total, 2) == 97358.30

# Independent calculation of the dropped rows' contribution.
dropped_with_products = dropped.merge(products, on="product_id", how="left")
dropped_with_products["order_value"] = (
    dropped_with_products["quantity"] * dropped_with_products["price"] *
    (1 - dropped_with_products["discount_pct"].fillna(0) / 100.0)
)
duplicate_delta = float(dropped_with_products["order_value"].sum())
print(f"Dropped duplicate rows' combined order_value: {duplicate_delta:,.2f}")
assert round(duplicate_delta, 2) == 2501.90

raw_total = clean_total + duplicate_delta
print(f"Raw total reconstructed from clean total + duplicate delta: {raw_total:,.2f}")
assert round(raw_total, 2) == 99860.20

print(
    f"Reconciliation note: Part 1's raw revenue is ₹{raw_total:,.2f}, while the "
    f"cleaned 175-row revenue is ₹{clean_total:,.2f}, a delta of ₹{duplicate_delta:,.2f}. "
    f"This exact ₹{duplicate_delta:,.2f} difference is attributable to the five duplicate "
    f"orders removed in Task 3. Their combined order_value is independently summed as "
    f"₹{duplicate_delta:,.2f}. Discount and rating imputation does not change order_value "
    f"because order_value uses discount_pct (with missing discount treated as 0) and never "
    f"uses rating."
)

print("\n" + "=" * 80)
print("TASK 6 — IQR OUTLIER DETECTION ON QUANTITY")
print("=" * 80)
q1 = float(merged["quantity"].quantile(0.25))
q3 = float(merged["quantity"].quantile(0.75))
iqr = q3 - q1
lower = q1 - 1.5 * iqr
upper = q3 + 1.5 * iqr
print(f"Q1={q1}, Q3={q3}, IQR={iqr}, lower={lower}, upper={upper}")
assert (q1, q3, iqr, lower, upper) == (1.0, 2.0, 1.0, -0.5, 3.5)

merged["is_outlier"] = ~merged["quantity"].between(lower, upper)
outliers = merged.loc[merged["is_outlier"], ["order_id", "quantity"]]
print("Outliers:")
print(outliers.to_string(index=False))
assert outliers["order_id"].tolist() == ["O0011", "O0098"]
assert outliers["quantity"].tolist() == [25, 30]

print("\n" + "=" * 80)
print("TASK 7 — HYPOTHESIS: DOES COD HAVE A HIGHER RETURN RATE?")
print("=" * 80)
print("Hypothesis: COD has a higher return rate than CARD and UPI.")
payment_return = orders_clean.groupby("payment_method")["returned"].agg(["count", "mean"])
payment_return["return_rate_pct"] = (payment_return["mean"] * 100).round(1)
print(payment_return[["count", "return_rate_pct"]])
expected_rates = {"CARD": 14.7, "COD": 44.4, "UPI": 18.9}
assert payment_return["return_rate_pct"].to_dict() == expected_rates
print("Hypothesis: Confirmed.")

print("\n" + "=" * 80)
print("TASK 8 — MULTI-LEVEL SEGMENTATION")
print("=" * 80)
segment = (
    merged.groupby(["payment_method", "city_tier"])["returned"]
    .agg(["count", "mean"])
    .reset_index()
)
segment["return_rate_pct"] = (segment["mean"] * 100).round(1)
print(segment[["payment_method", "city_tier", "count", "return_rate_pct"]].to_string(index=False))
highest_segment = segment.sort_values("return_rate_pct", ascending=False).iloc[0]
print(
    f"Highest-risk segment: {highest_segment['payment_method']} + Tier-{int(highest_segment['city_tier'])} "
    f"cities at {highest_segment['return_rate_pct']:.1f}%."
)
assert highest_segment["payment_method"] == "COD"
assert int(highest_segment["city_tier"]) == 2
assert float(highest_segment["return_rate_pct"]) == 54.5

print("\n" + "=" * 80)
print("TASK 9 — CORRELATION ANALYSIS")
print("=" * 80)
corr_cols = ["rating", "returned", "discount_pct", "quantity"]
corr = orders_clean[corr_cols].corr()
print(corr.to_string())

def band(r):
    a = abs(float(r))
    if a < 0.2:
        return "negligible"
    if a < 0.4:
        return "weak"
    if a < 0.7:
        return "moderate"
    return "strong"

pairs = []
for i in range(len(corr_cols)):
    for j in range(i + 1, len(corr_cols)):
        a, b = corr_cols[i], corr_cols[j]
        r = float(corr.loc[a, b])
        pairs.append((a, b, r, band(r)))
        print(f"{a} vs {b}: r={r:.4f} -> {band(r)}")

assert all(p[3] == "negligible" for p in pairs)
discount_return_r = float(corr.loc["discount_pct", "returned"])
print(
    f"Hypothesis 'higher discounts reduce returns': Busted "
    f"(discount_pct vs returned correlation = {discount_return_r:.4f}, negligible)."
)

print("\n" + "=" * 80)
print("TASK 10 — OUTLIER-CORRECTED TIME SERIES")
print("=" * 80)
merged["order_date"] = pd.to_datetime(merged["order_date"])
merged["year_month"] = merged["order_date"].dt.to_period("M").astype(str)

monthly_including = merged.groupby("year_month")["order_value"].sum().round(2)
monthly_excluding = (
    merged.loc[~merged["is_outlier"]]
    .groupby("year_month")["order_value"]
    .sum()
    .round(2)
)
print("Monthly revenue INCLUDING outliers:")
print(monthly_including.to_string())
print("\nMonthly revenue EXCLUDING outliers:")
print(monthly_excluding.to_string())

expected_including = {
    "2026-01": 29582.10,
    "2026-02": 13195.50,
    "2026-03": 20318.90,
    "2026-04": 9495.30,
    "2026-05": 13151.10,
    "2026-06": 11615.40,
}
expected_excluding = {
    "2026-01": 11637.10,
    "2026-02": 13195.50,
    "2026-03": 20318.90,
    "2026-04": 9495.30,
    "2026-05": 13151.10,
    "2026-06": 11615.40,
}
assert monthly_including.to_dict() == expected_including
assert monthly_excluding.to_dict() == expected_excluding

print(
    "Interpretation: January's apparent lead is an artifact of the two bulk orders "
    "landing in January (O0011 on 2026-01-28 and O0098 on 2026-01-10). "
    "Once those two outliers are excluded, March is the genuine peak month."
)

# -----------------------------
# Export verified findings.json
# -----------------------------
findings = {
    "cleaned_total_revenue_inr": round(clean_total, 2),
    "raw_total_revenue_inr": round(raw_total, 2),
    "duplicate_reconciliation_delta_inr": round(duplicate_delta, 2),
    "return_rate_by_payment": {
        k: float(payment_return.loc[k, "return_rate_pct"])
        for k in ["COD", "CARD", "UPI"]
    },
    "highest_risk_segment": {
        "payment_method": str(highest_segment["payment_method"]),
        "city_tier": int(highest_segment["city_tier"]),
        "return_rate_pct": float(highest_segment["return_rate_pct"]),
    },
    "true_peak_month": {
        "month": str(monthly_excluding.idxmax()),
        "revenue_inr": round(float(monthly_excluding.max()), 2),
    },
    "outlier_inflated_month": {
        "month": str(monthly_including.idxmax()),
        "apparent_revenue_inr": round(float(monthly_including.max()), 2),
        "corrected_revenue_inr": round(float(monthly_excluding.loc[monthly_including.idxmax()]), 2),
    },
}
expected_findings = {
    "cleaned_total_revenue_inr": 97358.30,
    "raw_total_revenue_inr": 99860.20,
    "duplicate_reconciliation_delta_inr": 2501.90,
    "return_rate_by_payment": {"COD": 44.4, "CARD": 14.7, "UPI": 18.9},
    "highest_risk_segment": {"payment_method": "COD", "city_tier": 2, "return_rate_pct": 54.5},
    "true_peak_month": {"month": "2026-03", "revenue_inr": 20318.90},
    "outlier_inflated_month": {"month": "2026-01", "apparent_revenue_inr": 29582.10, "corrected_revenue_inr": 11637.10},
}
assert findings == expected_findings

with open(NARRATOR / "findings.json", "w", encoding="utf-8") as f:
    json.dump(findings, f, indent=2)
    f.write("\n")
print("\nGenerated narrator/findings.json from computed Part 2 values.")
print(json.dumps(findings, indent=2))
